<?php

/**
*
*/
class Filemod extends \Epiqworx\Concrete\Controller {

  function uploadPowerPoint($option) {
    $this->setBlueprint('welcome');
    $name = $_FILES['file']['name'];
    $size = $_FILES['file']['size'];
    $type = $_FILES['file']['type'];
    $tmp_name = $_FILES['file']['tmp_name'];

    $extension = substr($name, strpos($name, '.') + 1);
    $max_size = 2000000000;
    if (isset($name) && !empty($name)) {
      if (($extension == "ppt" || $extension == "pptx") && $extension == $size <= $max_size) {
        $memberid = $_SESSION['member_id'];
        $active = $highlight = 1;
        $dir = "";
        $location = WEBUSR . "storage/" . $_SESSION['member_uname'] . "/root" . '/';
        if(!file_exists($location)) {
          mkdir($location, 0777, true);
          $dir = "INSERT INTO wc_directory(name, parentdir, location, sorting, ordered, member, created, modified, highlight, active)";
          $dir .= "VALUES ('/root', '', '/', 'name', 'ascending', $memberid, NOW(), NOW(), $highlight, $active)";
        }
        if (move_uploaded_file($tmp_name, $location . $name)) {
          $loc = str_replace(WEBUSR."storage/".$_SESSION['member_uname'], "", $location);
          $loc = "'".$loc."'";
          $mime = mime_content_type($location.$name);
          //$name = "'".$name."'";
          //$mime = "'".$mime."'";
          $thumbnail = "'00000.png'";
          if($dir !== "") {
            \Epiqworx\Abstraction\DBHandler::DMLi($dir);
          }
          $query = "SELECT id FROM wc_directory ORDER BY id DESC LIMIT 1;";
          $docdir = \Epiqworx\Abstraction\DBHandler::DQLi($query);
          $docdir = $docdir[0]['id'];
          $wcdocu = "INSERT INTO wc_document(name, created, modified, dsize, contentype, thumbnail, member, active, parentdir, highlight) VALUES ";
          $wcdocu .= "('$name', NOW(), NOW(), $size, '$mime', $thumbnail, $memberid, $active, $docdir, $highlight)";
          \Epiqworx\Abstraction\DBHandler::DMLi($wcdocu);
          $this->setFields("smsg", "Uploaded Successfully.");
        } else {
          $this->setFields("fmsg", "Failed to Upload File");
        }
      } else {
        $this->setFields("fmsg", "Failed to Upload File. File size too big. (Maximum 20M)");
      }
    } else {
      $this->setFields("fmsg", "Please Upload a PowerPoint Presentation File");
    }
    $this->setFields("req_ano", 'section/' . $option . '.php');
    $this->render();
  }

  function trashFile($option) {
    \Epiqworx\Abstraction\DBHandler::DMLi("UPDATE wc_file SET active = 2 WHERE id = $option");
    echo "<script> window.location.href = '?/Welcome/summon/home'; </script>";
  }

  function restoreFile($option) {
    \Epiqworx\Abstraction\DBHandler::DMLi("UPDATE wc_file SET active = 1 WHERE id = $option");
    echo "<script> window.location.href = '?/Welcome/summon/trash&trash=1'; </script>";
  }

  function updateFile($option) {
    $result = \Epiqworx\Abstraction\DBHandler::DQLqi("SELECT location, name FROM wc_file WHERE member = 1 AND active = 1 AND id = $option");
    $file = WEBUSR . 'storage/admin/' . $result['location'] . $result['name'];
    if (file_exists($file)) {
      $filename = htmlspecialchars($_POST['filename']) . '.' . htmlspecialchars($_POST['ext']);
      $colorflag = htmlspecialchars($_POST['colorflag']);
      rename($file, WEBUSR . 'storage/admin/' . $filename) or die("File renaming unsuccessful");
      \Epiqworx\Abstraction\DBHandler::DMLi("UPDATE wc_file SET name = '$filename', flag = $colorflag, modified = NOW() WHERE id = $option");
      echo "<script> window.location.href = '?/Welcome/summon/home'; </script>";
    } else {
      die("File does not exist unsuccessful renaming");
    }
  }

  function downloadFile($option) {
    $result = \Epiqworx\Abstraction\DBHandler::DQLqi("SELECT location, name FROM wc_file WHERE member = 1 AND active = 1 AND id = $option");
    $file = WEBUSR . 'storage/admin/' . $result['location'] . $result['name'];
    if (file_exists($file)) {
      header('Content-Description: File Transfer');
      header('Content-Type: application/octet-stream');
      header('Content-Disposition: attachment; filename="' . basename($file) . '"');
      header('Expires: 0');
      header('Cache-Control: must-revalidate');
      header('Pragma: public');
      header('Content-Length: ' . filesize($file));
      readfile($file);
      exit;
    } else {
      die('Error: The file ' . $local_file . ' does not exist!');
    }
  }

}

?>
