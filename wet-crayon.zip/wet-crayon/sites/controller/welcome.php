<?php

/**
*
*/
class Welcome extends \Epiqworx\Concrete\Controller
{
	function home() {
		$this->setBlueprint('welcome');
		$_SESSION['member_uname'] = 'straycat';
		$_SESSION['member_id'] = 1;
		$this->render();
	}

	function summon($option) {
    $opt = explode("&", $option);
		$this->setBlueprint("welcome");
		$this->setFields("req_ano", 'section/' . $opt[0] . '.php');
		$this->render();
	}
}
?>
