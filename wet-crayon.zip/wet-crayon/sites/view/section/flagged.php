
<div class="" style="margin: auto; padding-top: 50px;">
  <a href="?/Welcome/summon/home">
  <button class="btn-0" class="width-sm-20" style="font-size: 48pt;">
    <i class="fa fa-flag"></i>
    <span class="width-xs-20" style="font-size:22pt">No Flagged Files Found <br/> Try Adding Color Flags On Uploaded Files</span>
  </button>
  </a>
</div>
