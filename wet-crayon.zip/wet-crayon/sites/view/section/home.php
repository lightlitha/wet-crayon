<?php
$dirstatus = $docstatus = 1;
$dirid = 1;
$memberid = $_SESSION['member_id'];
//$ordsor  = \Epiqworx\Abstraction\DBHandler::DQLi("SELECT sorting, ordered FROM wc_directory WHERE id = $dirid");
$docquery = "SELECT doc.id, doc.name, doc.created, doc.modified, doc.dsize, doc.contentype, doc.thumbnail, hig.color, dir.location
FROM wc_document doc, wc_highlight hig, wc_directory dir
WHERE doc.active = $docstatus AND doc.parentdir = dir.id AND doc.member = $memberid AND hig.id = doc.highlight";
// ORDER BY $sorted $ordered";

$dirquery = "SELECT dir.id, dir.name, dir.location, dir.created, dir.modified, hig.color
FROM wc_directory dir, wc_highlight highlight
WHERE dir.active = $dirstatus AND dir.highlight = hig.id";
// ORDER BY $sorted $ordered";

//$diresult = \Epiqworx\Abstraction\DBHandler::DQLi($dirquery);
$doresult = \Epiqworx\Abstraction\DBHandler::DQLi($docquery);
?>
<div class="width-sm-1" style="height: 100%;"></div>
<?php if(empty($diresult) && empty($doresult)) { ?>
  <div class="" style="margin: auto; padding-top: 50px;">
    <a href="?/Welcome/summon/upload">
      <button class="btn-0" class="width-sm-20" style="font-size: 48pt;">
        <i class="fa fa-upload"></i>
        <span class="width-xs-20" style="font-size:22pt">No Files Found <br/> You Must Upload PowerPoint Files</span>
      </button>
    </a>
  </div>
<?php } ?>

<?php if(!empty($diresult)) { ?>
  <div class="img-row">
    <?php for($x = 0; $x < count($diresult); $x++) { ?>
      <div class="column">
        <a href="?/Welcome/summon/home&id=<?php echo $diresult[$x]['id']; ?>">
          <img src="sites/usr/img/1.png" alt="Avatar" style="width:100%">
        </a>
        <div class="container">
          <span class="width-xs-20 txt-c"><b><?php echo $diresult[$x]['name']?></b></span>
        </div>
      </div>
    <?php  } ?>
  </div>
<?php } ?>

<?php if(!empty($doresult)) { ?>
  <div class="img-row">
    <?php for($x = 0; $x < count($doresult); $x++) { ?>
      <div class="column">
        <a href="?/Welcome/summon/home&id=<?php echo $doresult[$x]['id']; ?>">
          <img src="sites/usr/img/1.png" alt="Avatar" style="width:100%">
        </a>
        <div class="container">
          <span class="width-xs-20 txt-c"><b><?php echo $doresult[$x]['name']?></b></span>
        </div>
      </div>
    <?php  } ?>
  </div>
<?php } ?>
