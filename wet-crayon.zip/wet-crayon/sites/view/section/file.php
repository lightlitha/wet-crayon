<style>
    
.fa-2x-a {
font-size: 2em;
}
.fa-a {
position: relative;
display: table-cell;
width: 60px;
height: 36px;
text-align: center;
vertical-align: middle;
font-size:20px;
}

.main-menu:hover,nav.main-menu.expanded {
width:250px;
overflow:visible;
}

.main-menu {
    float: left;
background:#212121;
border-right:1px solid #e5e5e5;
top:0;
bottom:0;
height:86.7%;
left:0;
width:60px;
overflow:hidden;
-webkit-transition:width .05s linear;
transition:width .05s linear;
-webkit-transform:translateZ(0) scale(1,1);
z-index:1000;
}

.main-menu>ul {
margin:7px 0;
}

.main-menu li {
position:relative;
display:block;
width:250px;
}

.main-menu li>a {
position:relative;
display:table;
border-collapse:collapse;
border-spacing:0;
color:#999;
font-family: arial;
font-size: 14px;
text-decoration:none;
-webkit-transform:translateZ(0) scale(1,1);
-webkit-transition:all .1s linear;
transition:all .1s linear;
  
}

.main-menu .nav-icon {
position:relative;
display:table-cell;
width:60px;
height:36px;
text-align:center;
vertical-align:middle;
font-size:18px;
}

.main-menu .nav-text {
position:relative;
display:table-cell;
vertical-align:middle;
width:190px;
font-family: 'Titillium Web', sans-serif;
}

.main-menu>ul.logout {
position:absolute;
left:0;
bottom:0;
}

.no-touch .scrollable.hover {
overflow-y:hidden;
}

.no-touch .scrollable.hover:hover {
overflow-y:auto;
overflow:visible;
}

a:hover,a:focus {
text-decoration:none;
}

nav {
-webkit-user-select:none;
-moz-user-select:none;
-ms-user-select:none;
-o-user-select:none;
user-select:none;
}

nav ul,nav li {
outline:0;
margin:0;
padding:0;
}

.main-menu li:hover>a,nav.main-menu li.active>a,.dropdown-menu>li>a:hover,.dropdown-menu>li>a:focus,.dropdown-menu>.active>a,.dropdown-menu>.active>a:hover,.dropdown-menu>.active>a:focus,.no-touch .dashboard-page nav.dashboard-menu ul li:hover a,.dashboard-page nav.dashboard-menu ul li.active a {
color:#fff;
background-color:#5fa2db;
}

.area {
float: left;
background: #e2e2e2;
width: 5%;
}

</style>

<div class="area"></div><nav class="main-menu">
            <ul>
                <li>
                    <a <?php if(!empty($_GET['id']) && !isset($_GET['trash'])) { echo 'href="#"' . htmlspecialchars($_GET['id']) . '"';} else {echo 'href="#"';} ?>>
                        <i class="fa-a fa-2x-a fa fa-eye fa-2x"></i>
                        <span class="nav-text">
                            View
                        </span>
                    </a>
                </li>
                <li class="has-subnav">
                    <a <?php if(isset($_GET['id']) && !isset($_GET['trash'])) { echo 'href="?/Filemod/downloadFile/"' . htmlspecialchars($_GET['id']) . '"';} else {echo 'href="#"';} ?>>
                        <i class="fa-a fa-2x-a fa fa-download fa-2x"></i>
                        <span class="nav-text">
                            Download
                        </span>
                    </a>
                </li>
                <li class="has-subnav">
                    <a <?php if(isset($_GET['id']) && !isset($_GET['trash'])) { echo 'href="?/Filemod/trashFile/"' . htmlspecialchars($_GET['id']) . '"';} else {echo 'href="#"';} ?>>
                       <i class="fa-a fa-2x-a fa fa-remove fa-2x"></i>
                        <span class="nav-text">
                            Remove
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a <?php if(isset($_GET['id']) && isset($_GET['trash'])) { echo 'href="?/Filemod/restoreFile/' . htmlspecialchars($_GET['id']) . '"';} else {echo 'href="#"';} ?>>
                       <i class="fa-a fa-2x-a fa fa-undo fa-2x"></i>
                        <span class="nav-text">
                            Restore
                        </span>
                    </a>
                   
                </li>
                <li>
                    <a href="#" onclick="document.getElementById('id01').style.display='block'">
                        <i class="fa-a fa-2x-a fa fa-folder-open fa-2x"></i>
                        <span class="nav-text">
                            New Folder
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fa-a fa-2x-a fa fa-file-powerpoint-o fa-2x"></i>
                        <span class="nav-text">
                           New Presentation
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                       <i class="fa-a fa-2x-a fa fa-pencil fa-2x"></i>
                        <span class="nav-text">
                            Update
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                       <i class="fa-a fa-2x-a fa fa-ellipsis-v fa-2x"></i>
                        <span class="nav-text">
                            Options
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                       <i class="fa-a fa-2x-a fa fa-question fa-2x"></i>
                        <span class="nav-text">
                            Help
                        </span>
                    </a>
                </li>
            </ul>

            <ul class="logout">
                <li>
                   <a href="#">
                         <i class="fa-a fa-2x-a fa fa-power-off fa-2x"></i>
                        <span class="nav-text">
                            Logout
                        </span>
                    </a>
                </li>  
            </ul>
        </nav>

<style>
    
/* Full-width input fields */
.modinput {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

/* Set a style for all buttons */
.modbtn {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

.modbtn:hover {
    opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}

/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

.createbtn {
    background-color: #09F9A7;
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
</style>

<div id="id01" class="modal">
  <form class="modal-content animate" action="/action_page.php">
    <div class="container">
      <label for="fname"><b>Create New Folder</b></label>
      <input type="text" placeholder="Folder Name" name="fname" required class="modinput">
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="modbtn cancelbtn">Cancel</button>
      <button type="button" onclick="" class="modbtn cancelbtn createbtn">Create</button>
    </div>
  </form>
</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>