
<div class="" style="margin: auto; padding-top: 50px;">
  <a href="?/Welcome/summon/home">
  <button class="btn-0" class="width-sm-20" style="font-size: 48pt;">
    <i class="fa fa-bell"></i>
    <span class="width-xs-20" style="font-size:22pt">No Notifications Found <br/> Ask Someone to share a file with you</span>
  </button>
  </a>
</div>
