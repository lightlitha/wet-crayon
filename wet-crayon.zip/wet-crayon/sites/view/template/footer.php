<script type="text/javascript">

function goToLink(gotolink) {
  location.href = gotolink;
}

</script>
