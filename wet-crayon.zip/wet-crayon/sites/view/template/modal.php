<style>
  .modal {
    display: none;
    position: fixed;
  }
</style>

<div id="fileModal" class="w3-modal">
    <div class="w3-modal-content">
      <div class="w3-modal-header">
        <span class="w3-close">&times;</span>
        <h2>Modal Header</h2>
      </div>
      <div class="w3-modal-body">
        <p>Some body Text</p>
      </div>
      <div class="w3-modal-footer">
        <p>Some footer Text</p>
      </div>
    </div>
</div>

<script>
  var modal = document.getElementById('fileModal');
  var btn = document.getElementById('fileBtn');
  var span = document.getElementById('close')[0];
  fileBtn.onclick = function() {
    modal.style.display = block;
  }
  span.onclick = function() {
    modal.style.display = "none";
  }
  window.onclick = function(event) {
    if(event.target == w3-modal) {
      modal.style.display = "none");
    }
  }
</script>
