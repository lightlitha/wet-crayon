# wet-crayon
File Management Repository

Every now and then I fall.
Every mow and than I lose control.
I see your eyes and my thoughts surround you you.
And a little bit apart from you.
If you are wondering why I talk like this now,
all of a Sunday,
its only one reason,
you were never precious to me,
but time made it so.
i tried to avoid it, never worked.
I looked at other people while trying to befriend you,
never worked.
I held myself back to avoid the things I needed to express to you, emotionally, mentally and physically.
to a point they were held up.

i used you as a prototype when looking for others, which they never matched your calabar. It feels like I am running in circles.

My life without you feels like an empty vessel.
You not the one for me, and I am not the one for you.
I made that i created it. i fulfilled it. It came true.
Some way some how. an error occurred that I cannot fix.

All I am trying to say is i am tired of making things  complicated. I cannot talk.
I know. I am not circumcised in my talk yes.
Allow me to express myself in anyway. Allow me to share my mind with you.
Allow me to share what is hidden, Allow me to share what cannot be seen but expressed.
what cannot be spoken but done.

It is what it is.
I can not alter the future nor the past.
everything I am not is everything I am.
Allow me to be me through you. Allow me to express myself.
Shine like the diamond I feel in my guts
The Jewel I feel will suit your neck,
A wrist that will guide your path to ever green postures.
