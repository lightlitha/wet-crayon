<?php

echo "$page <br/>";
echo "ERROR 404 IT IS";