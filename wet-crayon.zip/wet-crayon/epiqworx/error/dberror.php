<?php

echo "$page <br/>";
echo "ERROR Database : " . $emsg;